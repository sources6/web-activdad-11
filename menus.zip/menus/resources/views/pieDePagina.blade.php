<footer class="footer mt-auto py-3 bg-light">
  <div class="container text-center">
    <p>&copy; {{ date('Y') }} {{ Auth::user()->name ?? 'Tu nombre' }}</p>
  </div>
</footer>
